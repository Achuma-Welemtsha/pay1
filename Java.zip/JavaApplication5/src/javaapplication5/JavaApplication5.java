
package javaapplication5;

public class JavaApplication5 {
    public static void main(String[] args) {

        Scanner keyboard = new Scanner(System.in);
        double hours;
        double rate;
        double pay = 0;
        
        System.out.print("How many hours did you work? ");
        hours = keyboard.nextDouble();
        rate = keyboard.nextDouble();
        
        
        if (hours<= 40){
            
            pay = hours * pay;
            
        } else {
            
            if (hours >= 40)
                
                pay = hours * rate* pay;
        }
        System.out.println("you earned 0" + pay);
        }
    }
    
}
